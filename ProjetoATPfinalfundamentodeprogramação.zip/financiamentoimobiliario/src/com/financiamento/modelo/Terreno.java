package com.financiamento.modelo;

public class Terreno extends Financiamento {
    private static final double ACRESCIMO_RISCO = 0.02;
    private String tipoZona;

    public Terreno(double valorImovel, int prazoFinanciamento, double taxaJurosAnual, String tipoZona) {
        super(valorImovel, prazoFinanciamento, taxaJurosAnual);
        this.tipoZona = tipoZona;
    }

    public String getTipoZona() {
        return tipoZona;
    }

    @Override
    public double calcularPagamentoMensal() {
        double pagamentoBase = super.calcularPagamentoMensal();
        return pagamentoBase * (1 + ACRESCIMO_RISCO);
    }

    @Override
    public void mostrarDadosFinanciamento() {
        super.mostrarDadosFinanciamento();
        System.out.println("Tipo de Zona: " + tipoZona);
        System.out.println("Pagamento Mensal: R$ " + String.format("%.2f", calcularPagamentoMensal()).replace('.', ','));
        System.out.println("Total do Pagamento: R$ " + String.format("%.2f", calcularTotalPagamento()).replace('.', ','));
    }
}
