package com.financiamento.main;

import com.financiamento.modelo.Casa;
import com.financiamento.modelo.Apartamento;
import com.financiamento.modelo.Terreno;
import com.financiamento.modelo.Financiamento;
import com.financiamento.util.InterfaceUsuario;
import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        InterfaceUsuario interfaceUsuario = new InterfaceUsuario();

        ArrayList<Financiamento> financiamentos = new ArrayList<>();

        System.out.println("Digite os dados para o primeiro financiamento:");
        double valorImovel = interfaceUsuario.pedirValorImovel();
        int prazoFinanciamento = interfaceUsuario.pedirPrazoFinanciamento();
        double taxaJurosAnual = interfaceUsuario.pedirTaxaJuros();

        financiamentos.add(new Casa(valorIm