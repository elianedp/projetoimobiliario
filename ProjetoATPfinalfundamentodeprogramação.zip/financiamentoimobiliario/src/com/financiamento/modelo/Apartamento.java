package com.financiamento.modelo;

public class Apartamento extends Financiamento {
    private int numeroVagasGaragem;
    private int numeroAndar;

    public Apartamento(double valorImovel, int prazoFinanciamento, double taxaJurosAnual, int numeroVagasGaragem, int numeroAndar) {
        super(valorImovel, prazoFinanciamento, taxaJurosAnual);
        this.numeroVagasGaragem = numeroVagasGaragem;
        this.numeroAndar = numeroAndar;
    }

    @Override
    public double calcularPagamentoMensal() {
        double taxaMensal = getTaxaJurosAnual() / 12 / 100; // Convertendo para decimal
        int meses = getPrazoFinanciamento() * 12;
        double valorImovel = getValorImovel();

        return (valorImovel * Math.pow(1 + taxaMensal, meses) * taxaMensal) / (Math.pow(1 + taxaMensal, meses) - 1);
    }

    @Override
    public void mostrarDetalhesEspecificos() {
        System.out.println("Número de Vagas na Garagem: " + numeroVagasGaragem);
        System.out.println("Número do Andar: " + numeroAndar);
    }
}
