package com.financiamento.modelo;

import com.financiamento.exception.DescontoMaiorDoQueJurosException;

public class Casa extends Financiamento {
    private static final double VALOR_SEGURO = 80;
    private double areaConstruida;
    private double tamanhoTerreno;

    public Casa(double valorImovel, int prazoFinanciamento, double taxaJurosAnual, double areaConstruida, double tamanhoTerreno) {
        super(valorImovel, prazoFinanciamento, taxaJurosAnual);
        this.areaConstruida = areaConstruida;
        this.tamanhoTerreno = tamanhoTerreno;
    }

    public double getAreaConstruida() {
        return areaConstruida;
    }

    public double getTamanhoTerreno() {
        return tamanhoTerreno;
    }

    @Override
    public double calcularPagamentoMensal() {
        double pagamentoBase = super.calcularPagamentoMensal();
        return pagamentoBase + VALOR_SEGURO;
    }

    public void aplicarDesconto(double desconto) throws DescontoMaiorDoQueJurosException {
        if (desconto > getTaxaJurosAnual() / 12) {
            throw new DescontoMaiorDoQueJurosException("Desconto maior do que os juros mensais.");
        }
    }

    @Override
    public void mostrarDadosFinanciamento() {
        super.mostrarDadosFinanciamento();
        System.out.println("Área Construída: " + String.format("%.2f", areaConstruida).replace('.', ',') + " m²");
        System.out.println("Tamanho do Terreno: " + String.format("%.2f", tamanhoTerreno).replace('.', ',') + " m²");
        System.out.println("Pagamento Mensal: R$ " + String.format("%.2f", calcularPagamentoMensal()).replace('.', ','));
        System.out.println("Total do Pagamento: R$ " + String.format("%.2f", calcularTotalPagamento()).replace('.', ','));
    }
}
