package com.financiamento.exception;

// Exceção personalizada para descontos maiores do que os juros
public class DescontoMaiorDoQueJurosException extends Exception {
    public DescontoMaiorDoQueJurosException(String mensagem) {
        super(mensagem);
    }
}