package com.financiamento.main;

import com.financiamento.modelo.Casa;
import com.financiamento.modelo.Apartamento;
import com.financiamento.modelo.Terreno;
import com.financiamento.modelo.Financiamento;
import com.financiamento.util.InterfaceUsuario;

import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        InterfaceUsuario interfaceUsuario = new InterfaceUsuario();

        ArrayList<Financiamento> financiamentos = new ArrayList<>();

        // Solicitar dados do usuário para um financiamento
        System.out.println("Digite os dados para o financiamento de uma Casa:");
        double valorImovel = interfaceUsuario.pedirValorImovel();
        int prazoFinanciamento = interfaceUsuario.pedirPrazoFinanciamento();
        double taxaJurosAnual = interfaceUsuario.pedirTaxaJuros();
        double areaConstruida = interfaceUsuario.pedirAreaConstruida();
        double tamanhoTerreno = interfaceUsuario.pedirTamanhoTerreno();

        financiamentos.add(new Casa(valorImovel, prazoFinanciamento, taxaJurosAnual, areaConstruida, tamanhoTerreno));

        // Adicionar demais financiamentos diretamente no código
        financiamentos.add(new Casa(300000, 15, 4.5, 120, 250));
        financiamentos.add(new Apartamento(150000, 10, 5, 2, 5));
        financiamentos.add(new Apartamento(450000, 30, 3.5, 3, 10));
        financiamentos.add(new Terreno(200000, 20, 3.75, "Residencial"));

        // Exibir os detalhes dos financiamentos
        System.out.println("\n=== Detalhes dos Financiamentos ===");
        for (Financiamento financiamento : financiamentos) {
            financiamento.mostrarDadosFinanciamento();
            System.out.println("------------------------------------------");
        }

        // Calcular e exibir o total dos valores dos imóveis e financiamentos
        double totalImoveis = 0;
        double totalFinanciamentos = 0;
        for (Financiamento financiamento : financiamentos) {
            totalImoveis += financiamento.getValorImovel();
            totalFinanciamentos += financiamento.calcularTotalPagamento();
        }

        System.out.println("=== Resumo ===");
        System.out.println("Total de todos os imóveis: R$ " + String.format("%.2f", totalImoveis));
        System.out.println("Total de todos os financiamentos: R$ " + String.format("%.2f", totalFinanciamentos));
        System.out.println("==========================================");
    }
}
