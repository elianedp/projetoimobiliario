package com.financiamento.util;

import java.util.InputMismatchException;
import java.util.Scanner;

public class InterfaceUsuario {
    private Scanner scanner;

    public InterfaceUsuario() {
        scanner = new Scanner(System.in);
    }

    public double pedirValorImovel() {
        double valorImovel = -1;
        do {
            try {
                System.out.print("Digite o valor do imóvel: ");
                String input = scanner.next().replace(',', '.');
                valorImovel = Double.parseDouble(input);
                if (valorImovel <= 0) {
                    System.out.println("O valor do imóvel deve ser positivo.");
                    valorImovel = -1; // reseta o valor para continuar no loop
                }
            } catch (InputMismatchException | NumberFormatException e) {
                System.out.println("Entrada inválida. Por favor, digite um número.");
                scanner.next(); // limpa a entrada inválida
            }
        } while (valorImovel <= 0);
        return valorImovel;
    }

    public int pedirPrazoFinanciamento() {
        int prazo = -1;
        do {
            try {
                System.out.print("Digite o prazo do financiamento (em anos): ");
                prazo = scanner.nextInt();
                if (prazo <= 0) {
                    System.out.println("O prazo deve ser positivo.");
                    prazo = -1;
                }
            } catch (InputMismatchException e) {
                System.out.println("Entrada inválida. Por favor, digite um número inteiro.");
                scanner.next();
            }
        } while (prazo <= 0);
        return prazo;
    }

    public double pedirTaxaJuros() {
        double taxa = -1;
        do {
            try {
                System.out.print("Digite a taxa de juros anual (em %): ");
                String input = scanner.next().replace(',', '.');
                taxa = Double.parseDouble(input);
                if (taxa <= 0) {
                    System.out.println("A taxa de juros deve ser positiva.");
                    taxa = -1;
                }
            } catch (InputMismatchException | NumberFormatException e) {
                System.out.println("Entrada inválida. Por favor, digite um número.");
                scanner.next();
            }
        } while (taxa <= 0);
        return taxa;
    }

    public double pedirAreaConstruida() {
        double areaConstruida = -1;
        do {
            try {
                System.out.print("Digite o tamanho da área construída (em m²): ");
                areaConstruida = scanner.nextDouble();
                if (areaConstruida <= 0) {
                    System.out.println("O tamanho da área construída deve ser positivo.");
                    areaConstruida = -1;
                }
            } catch (InputMismatchException e) {
                System.out.println("Entrada inválida. Por favor, digite um número.");
                scanner.next();
            }
        } while (areaConstruida <= 0);
        return areaConstruida;
    }

    public double pedirTamanhoTerreno() {
        double tamanhoTerreno = -1;
        do {
            try {
                System.out.print("Digite o tamanho do terreno (em m²): ");
                tamanhoTerreno = scanner.nextDouble();
                if (tamanhoTerreno <= 0) {
                    System.out.println("O tamanho do terreno deve ser positivo.");
                    tamanhoTerreno = -1;
                }
            } catch (InputMismatchException e) {
                System.out.println("Entrada inválida. Por favor, digite um número.");
                scanner.next();
            }
        } while (tamanhoTerreno <= 0);
        return tamanhoTerreno;
    }
}
